import UIKit

/*
Assignment 3 (Inheritance and Method Overriding)

Details

Superclass : Computer

Three Subclasses: Laptop, Desktop, and Server

Requirements

A function to display detailed specifications of each computer type.

Superclass: Computer
    Properties:
        brand: String
        processor: String
        ram: Int (amount of RAM in GB)
    Methods:
        displaySpecs(): Prints the computers details

Create Subclasses:

Subclass 1: Laptop
    Additional properties:
        isTouchscreen: bool
    Additional Methods:
        Override the displaySpecs() method to include this property.

Subclass 2: Desktop
    Additional properties:
        hasDedicatedGPU: bool
    Additionl Methods:
        Override the displaySpecs() method to include this property.

Subclass 3: Server
    Additional properties:
        rackUnits: Int
    Additional Methods:
        Override the displaySpecs() method to include this property.

Write some test code:


Sample Output:

Laptop Specs:
Brand: Apple, Processor: M1, RAM: 16GB
Touchscreen: No

Desktop Specs:
Brand: Dell, Processor: Intel i7, RAM: 32GB
Dedicated GPU: Yes

Server Specs:
Brand: HP, Processor: Xeon, RAM: 64GB
Rack Units: 4
*/

//==============================>>
//==== Superclass: Computer ====>>
class Computer {
    private var brand: String
    private var processor: String
    private var ram: Int
    
    init(brand: String, processor: String, ram: Int) {
        self.brand = brand
        self.processor = processor
        self.ram = ram
    } // init
    // getters
    func getBrand() -> String {
        return self.brand
    }
    func getProcessor() -> String {
        return self.processor
    }
    func getRam() -> Int {
        return self.ram
    }
    // print message
    func displaySpecs(){
        print("Generic PC: \n Brand: \(self.brand) CPU Type: \(self.processor) RAM: \(self.ram)")
    } // func
} // class
//===========================>>
//==== Subclass1: Laptop ====>>
class Laptop: Computer {
    private var isTouchscreen: Bool
    
    init(brand: String, processor: String, ram: Int, isTouchscreen: Bool) {
        self.isTouchscreen = isTouchscreen
        super.init(brand: brand, processor: processor, ram: ram)
    } // init
    // getters
    override func displaySpecs() {
        print("Laptop Specs: \n Brand: \(super.getBrand()) CPU Type: \(super.getProcessor()) RAM: \(super.getRam())GB")
    } // override
    func screenType() {
        if self.isTouchscreen == true {
            print(" Touchscreen: Yes")
        } else {
            print(" Touchscreen: No")
        }
    } // func
}//subclass1
//============================>>
//==== Subclass2: Desktop ====>>
class Desktop: Computer {
    private var hasDedicatedGPU: Bool
     
    init(brand: String, processor: String, ram: Int, hasDedicated: Bool) {
        self.hasDedicatedGPU = hasDedicated
        super.init(brand: brand, processor: processor, ram: ram)
    } // init
    // getters
    override func displaySpecs() {
        print("Desktop Specs: \n Brand: \(super.getBrand()) CPU Type: \(super.getProcessor()) RAM: \(super.getRam())GB")
    } // override
    func graphicsCard() {
        if self.hasDedicatedGPU == true {
            print(" Dedicated GPU: Yes")
        } else {
            print(" Dedicated GPU: No")
        }
    } // func
}//subclass2
//===========================>>
//==== Subclass3: Server ====>>
class Server: Computer {
    private var rackUnits: Double
      
    init(brand: String, processor: String, ram: Int, rackUnits: Double) {
        self.rackUnits = rackUnits
        super.init(brand: brand, processor: processor, ram: ram)
    } // init
    // getters
    override func displaySpecs() {
        print("Server Specs: \n Brand: \(super.getBrand()) CPU Type: \(super.getProcessor()) RAM: \(super.getRam())GB")
    } // override
      // setters
    func setHeight() {
        print(" Rack Units: \(rackUnits)U")
    } // func
}//subclass3
//============================>>
//====== Output Testing ======>>
// Variables to fill data
var genericComputer: Computer = Computer(brand: "Hewlett Packard\n",
                                         processor: "Intel\n",
                                         ram: 128)
var Notebook: Laptop = Laptop(brand: "Apple\n",
                              processor: "M4\n",
                              ram: 16,
                              isTouchscreen: false)
var MiniPC: Desktop = Desktop(brand: "Lenovo\n",
                              processor: "i7\n",
                              ram: 32,
                              hasDedicated: true)
var TheBox: Server = Server(brand: "Dell\n",
                              processor: "Zeon\n",
                              ram: 128,
                              rackUnits: 2.5)
// Print statements for Output
genericComputer.displaySpecs()
print()
Notebook.displaySpecs()
Notebook.screenType()
print()
MiniPC.displaySpecs()
MiniPC.graphicsCard()
print()
TheBox.displaySpecs()
TheBox.setHeight()

